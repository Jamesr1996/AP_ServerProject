import java.sql.*; 
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class SetUpDB extends GenericDBCommand {

  public SetUpDB(String dbType) {
    super(dbType);
  } 

  public void execute() {
    try { 
  // Create a connection object (conn) use the getConnection() method of the GenericDBCommand
    	Connection conn = getConnection ();
  // Execute SQL statements etc
    
  //.......
      // create a statement object (stmt) on the connection
    	Statement stmt = conn.createStatement();
      //.......
      
    // Clear the batch of the statement object use the method clearBatch() of the statment class
     stmt.clearBatch();
    	//check method in the java class library
      //.......
    	
     try {
      // Read the text file Setup_Year2.txt which includes SQL commands
    	 
      //  Use a BufferedReader on the inputStreamReader of the FileInputStream 
    	FileReader fr = new FileReader("Z:/advacance_programming_java/Seas_Year2.txt");
    	BufferedReader in = new BufferedReader(fr);

	String line;

	while ((line = in.readLine()) != null && !line.equals("")) {
		
      //Add the list of SQL commands to the created Statement object.
      //use the method addBatch() of the statment class
      //check method and its functionality in the java class library
      //..........
		System.out.println(line + " ");
		stmt.execute(line);
	}
      } catch (IOException e) {
	System.out.println(e);
	return;
      }
    } catch (SQLException sqle) {
      System.out.println(sqle);
    }
  }
  
  private Connection clearBatch() {
	// TODO Auto-generated method stub
	return null;
}

public static void main(String[] args) {
    if (args.length == 1) {
      SetUpDB gbl = new SetUpDB(args[0]);
      gbl.makeConnection();
    } else {
      System.out.println("command line argument: either oracle or access");
      System.exit(0);
    }
  }
}
