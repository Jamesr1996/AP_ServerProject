package msgServer;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

public class ModifySetReminders extends DBCommand implements Command {
	private BufferedReader in;
	private BufferedWriter out;
	private MsgSvrConnection conn;
	private Date date;
	private String remName = "";

	public ModifySetReminders(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn) {
		this.in = in;
		this.out = out;
		this.conn = serverConn;
	}

	public void execute() throws IOException {
		try {

			// Connect to DB
			Connection dbconn = getConnection();
			Statement stmt = dbconn.createStatement();
			stmt.clearBatch();

			// Get all set reminders for the current user
			ResultSet rs = stmt.executeQuery("SELECT * FROM Reminders WHERE Username='" + conn.getCurrentUser() + "';");
			while (rs.next()) {
				out.write(rs.getString("Rem_Name") + "   " + rs.getString("Rem_Date") + "\r\n");
			}
			
			// Choose reminder to update			
			out.write("\r\nEnter the reminder to update:\r\n");
			out.flush();
			String oldRem = in.readLine();

			out.write("Enter a new reminder name:\r\n");
			out.flush();
			remName = in.readLine();

			out.write("Enter a date for the reminder (YYYY-MM-DD):\r\n");
			out.flush();
			String days = in.readLine();

			out.write("Enter a reminder time (HH:mm:ss):\r\n");
			out.flush();
			String time = in.readLine();

			// Update the reminders DB with the new values
			stmt.execute("UPDATE Reminders SET Rem_Name='" + remName + "', Rem_Date=#" + days + " " + time
					+ "# WHERE Rem_Name='" + oldRem + "';");

			stmt.close();

			out.write("200\r\n");
			out.flush();

		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (SQLException sqle) {
			System.err.println(sqle);
		}
	}
}
