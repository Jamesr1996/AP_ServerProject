package msgServer;

import java.sql.Connection;
import java.sql.Statement;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class ReminderChecker extends DBCommand implements Runnable {

	private String nextRemDate = "";
	private String remName = "";
	private boolean delete = false;

	public ReminderChecker() {
		run();
	}

	public void execute() throws IOException{
		updateReminders();
		while (true) {
			try {
				// Get Current Time
				Calendar cal = Calendar.getInstance();
				Date currDate = cal.getTime();
				
				// Format the date
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				String dateForm = dateFormat.format(currDate);

				// Eliminate the milliseconds added by SQL
				Date date2 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(nextRemDate);
				String reminderDate = dateFormat.format(date2);

				System.out.println("Curr :" + dateForm);
				System.out.println("Next rem: " + reminderDate);

				// Check reminder is equal to current timedate.
				// Display Popup and then call updateReminders();
				if (dateForm.equals(reminderDate)) {
					JOptionPane.showMessageDialog(null, ("Reminder for: " + remName), remName,
							JOptionPane.INFORMATION_MESSAGE);
					delete = true;
					updateReminders();

				}
				Thread.currentThread().sleep(1000);

			} catch (InterruptedException ie) {
				System.err.println(ie);
			} catch (ParseException pe) {
				System.err.println(pe);
			}
		}
	}

	public void updateReminders() {
		try {
			// Connect to DB
			Connection dbconn = getConnection();
			Statement stmt = dbconn.createStatement();
			stmt.clearBatch();
			
			// Extract records and sort by Date
			ResultSet rs = stmt.executeQuery("SELECT * FROM Reminders ORDER BY Rem_Date");
			
			// Create a date pointing to the current time
			Calendar cal = Calendar.getInstance();
			Date currDate = cal.getTime();
			
			//Sets the format for the date
			Date dbDate = null;
			if (nextRemDate != "") {
				dbDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(nextRemDate);
				System.out.println(nextRemDate);
			}
			
			if (nextRemDate == "" || dbDate.before(currDate)){
				if (rs.next()) {
					// Get the data within the column.
					nextRemDate = rs.getString("Rem_Date");
					remName = rs.getString("Rem_Name");
				} else {
					Thread.currentThread().sleep(1000);
					System.out.println("Waiting for reminders");
					updateReminders();
				}
			}
			if (delete == true){
				stmt.execute("DELETE FROM Reminders WHERE Rem_Date='" + nextRemDate + "';");
				delete = false; 
			}
			stmt.close();

		} catch (SQLException sqle) {
			System.err.println(sqle);
		} catch (InterruptedException ie) {
			System.err.println(ie);
		} catch (ParseException pe){
			System.err.println(pe);
		}
	}

	@Override
	public void run() {
		try{
			execute();
		} catch (IOException e){
			System.err.println(e);
		}

	}
}
