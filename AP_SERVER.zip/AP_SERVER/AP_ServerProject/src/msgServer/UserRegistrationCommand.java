package msgServer;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.sql.*;
import java.io.FileWriter;
import java.io.IOException;


public class UserRegistrationCommand extends DBCommand implements Command {
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	
	/**
	 * Execute the command.
	 */
	public void execute() throws IOException {
		{
			try
			{	
				Connection dbconn = getConnection();
				Statement stmt = dbconn.createStatement();
				stmt.clearBatch();
				
				FileWriter fw = new FileWriter(MsgProtocol.PASSWORD_FILE, true);	
				BufferedWriter bw = new BufferedWriter(fw);
				
				out.write("Username:\r\n");
				out.flush();
				bw.newLine();
				String username = in.readLine();
				bw.write(username);	

				out.write("Password:\r\n");
				out.flush();
				bw.write(" " + in.readLine());
				
				out.write("DoB (YYYY-MM-DD):\r\n");
				out.flush();
				String dob = in.readLine();
				
				out.write("Tel no:\r\n");
				out.flush();
				String tel = in.readLine();
				
				out.write("Address:\r\n");
				out.flush();
				String addr = in.readLine();
				
				bw.flush();
				
				System.out.println("Flushed");
				fw.close();
				bw.close();
				System.out.println("Closed");
				
				out.write("200\r\n");
				out.flush();
				String statement = "INSERT INTO UserDetails VALUES('" + username + "', #" + dob + "#, '" + tel + "', '" + addr + "')";
				stmt.execute(statement);
				stmt.close();
			}catch(IOException e){
				System.out.println(e.getMessage());
			}catch(SQLException sqle){
			}
		}
	}

	public UserRegistrationCommand(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn) throws IOException
	{
			this.in = in;
			this.out = out;
			this.conn = serverConn;
		}
	
}