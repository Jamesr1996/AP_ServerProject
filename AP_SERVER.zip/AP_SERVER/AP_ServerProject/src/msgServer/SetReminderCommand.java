package msgServer;

import java.io.*;
import java.sql.*;
import java.util.Date;
import java.util.Calendar;
import java.text.ParseException;
import java.text.SimpleDateFormat;


public class SetReminderCommand extends DBCommand implements Command {
	private BufferedWriter out;
	private BufferedReader in;
	private MsgSvrConnection conn;
	private Date date;
	private String remName = "";

	/**
	 * Execute the command.
	 */

	public SetReminderCommand(BufferedReader in, BufferedWriter out, MsgSvrConnection serverConn) throws IOException {
		this.in = in;
		this.out = out;
		this.conn = serverConn;
	}

	public void execute() throws IOException {
			try	{
				
				// Connect to DB
				Connection dbconn = getConnection();
				Statement stmt = dbconn.createStatement();
				stmt.clearBatch();
				
				// Record the Reminder Name
				out.write("Enter a reminder name:\r\n");
				out.flush();
				remName = in.readLine();
				
				// Record the Reminder Date
				out.write("Enter a date for the reminder (YYYY-MM-DD):\r\n");
				out.flush();
				String days = in.readLine();
				
				// Record the Reminder Time
				out.write("Enter a reminder time (HH:mm:ss):\r\n");
				out.flush();
				String time = in.readLine();
				
				String remDate = days + " " + time;
				Calendar cal = Calendar.getInstance();
				Date currDate = cal.getTime();
				Date proposedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(remDate);
				
				if (proposedDate.before(currDate)){
					out.write("Proposed date has already passed\r\n");
					execute();
				}
				
				// Insert into DB records for name, date & time
				String statement = "'" + conn.getCurrentUser() + "', '" + remName + "', #"+ remDate + "#)";
				stmt.execute("INSERT INTO Reminders VALUES("+statement);
				
				stmt.close();
				
				out.write("200\r\n");
				out.flush();
				
			} catch (IOException e){
				System.out.println(e.getMessage());
			} catch (SQLException sqle){
			} catch (ParseException p){
				System.err.println(p);
			}
		}
		
}
