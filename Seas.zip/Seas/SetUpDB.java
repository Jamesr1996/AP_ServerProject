import java.sql.*; 
import java.io.FileInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.IOException;

public class SetUpDB extends GenericDBCommand {

  public SetUpDB(String dbType) {
    super(dbType);
  } 

  public void execute() {
    try { 
      // Create a connection object (conn) use the getConnection() method of the GenericDBCommand 
      //.......
      // create a statement object (stmt) on the connection
      //.......
      // Clear the batch of the statement object use the method clearBatch() of the statment class
      //check method in the java class library
      //.......
    
     try {
      // Read the text file Setup_Year2.txt which includes SQL commands
      //  Use a BufferedReader on the inputStreamReader of the FileInputStream 
      // BufferedReader in = .......

	String line;

	while ((line = in.readLine()) != null && !line.equals("")) {
      //Add the list of SQL commands to the created Statement object.
      //use the method addBatch() of the statment class
      //check method and its functionality in the java class library
      //..........
	}
      } catch (IOException e) {
	System.out.println(e);
	return;
      }
      try {
      //Submit the batch of commands in the stmt object to the database for execution
      //use the method executeBatch() 
      //......
      } catch (BatchUpdateException bue) {
	System.out.println(bue);
      }
    } catch (SQLException sqle) {
      System.out.println(sqle);
    }
  }
  
  public static void main(String[] args) {
    if (args.length == 1) {
      SetUpDB gbl = new SetUpDB(args[0]);
      gbl.makeConnection();
    } else {
      System.out.println("command line argument: either oracle or access");
      System.exit(0);
    }
  }
}
