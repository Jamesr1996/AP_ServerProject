import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.*; 
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.IOException;

public class GetStudentsList extends GenericDBCommand {

  public GetStudentsList(String dbType) {
    super(dbType);
  }

  public void execute() {
    try { 
      Connection conn = getConnection();
      ResultSet rs = executeStatement(conn);
      processResults(rs);
    } catch (SQLException sqle) {
      System.out.println(sqle);
    }
  }
  
  private ResultSet executeStatement(Connection conn) throws SQLException {
    Statement stmt = conn.createStatement();
    String sql = "SELECT Seas_Year2.Student_Name, Courses.Course_Name, Seas_Year2.Course_Grade  "+
                 "FROM Seas_Year2, Courses "+
                 "WHERE Seas_Year2.Course_Code = Courses.Course_Code and "+
                 "Courses.Course_Lecturer = 'D. J. Evans' " +
                 "ORDER BY Courses.Course_Name";
  
    System.out.println("Query is: " + sql);
    return stmt.executeQuery(sql);
  }
  
  private void processResults(ResultSet rs) throws SQLException {
    ResultSetMetaData md = rs.getMetaData();
    int cols = md.getColumnCount();
    OutputStreamWriter out = null;
    try {
      // nice easy way to generate a table is in HTML
      // so we create a HTML file called result.html
      
      //Add your Code here..........................
      // Create an outputstream (out) stream that connects to result.html 
      
      // Use out to create the header for your html file

      // DayOfWeek Month Day Hour:Minutes:Seconds Year
      SimpleDateFormat formatter
	    = new SimpleDateFormat ("EEE MMM d H:mm:ss yyyy");
      String dateString = formatter.format(new Date()) + "\r\n";

      out.write("<h1>Query result at " + dateString + "</h1>");
      out.write("<table border='1'>\n<tr>");
      for (int i=1; i<=cols; i++) {
	out.write("<th>" + md.getColumnName(i)+ "</th>");
      }
      out.write("</tr>\n");
      while (rs.next()) {
      //Add your Code here..........................
      
      }   
      out.write("</table></body></html>\n");
    } catch (IOException e) {
      System.out.println("Error writing file: " + e);
    } finally {
      if (out != null) {
	try {
	  out.close();
	  System.out.println("You will find the results in result.html");
	} catch (IOException e) {}
      }
    }
  }
  
  public static void main(String[] args) {
    if (args.length == 1) {
      GetStudentsList gbl = new GetStudentsList(args[0]);
      gbl.makeConnection();
    } else {
      System.out.println("command line argument: either oracle or access");
      System.exit(0);
    }
  }
}

